#include "hash-sha256.c"
#include "hash.h"
#include <stdlib.h>
#include <time.h>

/* Массив паролей */
#define BATCH_SIZE 1
#define i 22


char inputArray[i] = "S";  
char password_hash[64] = "0000000000000000000000000000000000000000000000000000000000000000";
char characters[57] = "23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"; 
int password_max_length;
int k, c;
int main(int argc, char *argv[]) {
	char outputArray[65];
    	for(c = 1; c < 22;c++) {
    	    	
    	    batch_hash(inputArray, outputArray, i, BATCH_SIZE);
    	    for(k = 0; k < BATCH_SIZE; k++) {
	        	if (!strcmp("0", outputArray[0])) {
	    	    	printf("Password found: %s\n", outputArray); 
	}
    }
    }
	return 0;
}
